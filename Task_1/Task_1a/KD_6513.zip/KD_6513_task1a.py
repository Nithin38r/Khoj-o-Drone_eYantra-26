#!/usr/bin/env python3

import argparse
import os
import cv2
import numpy as np


REQUIRED_MARKERS = [80, 85, 90, 95]
WARP_SIZE = 900
GRID_CELLS = 12
CELL_SIZE = WARP_SIZE / GRID_CELLS
MIN_OBJECT_AREA = 1000


def detect_markers(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    dictionary = cv2.aruco.getPredefinedDictionary(
        cv2.aruco.DICT_4X4_250
    )

    # Support both newer and older OpenCV ArUco APIs.
    if hasattr(cv2.aruco, "ArucoDetector"):
        parameters = cv2.aruco.DetectorParameters()
        detector = cv2.aruco.ArucoDetector(
            dictionary,
            parameters
        )
        corners, ids, _ = detector.detectMarkers(gray)
    else:
        parameters = cv2.aruco.DetectorParameters_create()
        corners, ids, _ = cv2.aruco.detectMarkers(
            gray,
            dictionary,
            parameters=parameters
        )

    if ids is None:
        raise RuntimeError("No ArUco markers detected")

    marker_points = {}

    for marker_id, marker_corners in zip(ids.flatten(), corners):
        marker_points[int(marker_id)] = marker_corners[0]

    missing = [
        marker_id
        for marker_id in REQUIRED_MARKERS
        if marker_id not in marker_points
    ]

    if missing:
        raise RuntimeError(
            f"Missing required ArUco markers: {missing}"
        )

    return marker_points


def perspective_transform(image, marker_points):

    # Inner arena corners.
    #
    # Marker 80 -> top-left
    # Marker 85 -> top-right
    # Marker 90 -> bottom-right
    # Marker 95 -> bottom-left

    src = np.array([
        marker_points[80][0],
        marker_points[85][1],
        marker_points[90][2],
        marker_points[95][3]
    ], dtype=np.float32)

    dst = np.array([
        [0, 0],
        [899, 0],
        [899, 899],
        [0, 899]
    ], dtype=np.float32)

    matrix = cv2.getPerspectiveTransform(src, dst)

    return cv2.warpPerspective(
        image,
        matrix,
        (WARP_SIZE, WARP_SIZE)
    )


def detect_survivors(warped):

    hsv = cv2.cvtColor(warped, cv2.COLOR_BGR2HSV)

    # Red mask
    red1 = cv2.inRange(
        hsv,
        np.array([0, 100, 80]),
        np.array([10, 255, 255])
    )

    red2 = cv2.inRange(
        hsv,
        np.array([170, 100, 80]),
        np.array([180, 255, 255])
    )

    red_mask = cv2.bitwise_or(red1, red2)

    # Yellow mask
    yellow_mask = cv2.inRange(
        hsv,
        np.array([20, 100, 80]),
        np.array([40, 255, 255])
    )

    masks = {
        "Critical Survivors": red_mask,
        "Stable Survivors": yellow_mask
    }

    results = {}

    for category, mask in masks.items():

        contours, _ = cv2.findContours(
            mask,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE
        )

        locations = []

        for contour in contours:

            area = cv2.contourArea(contour)

            if area < MIN_OBJECT_AREA:
                continue

            moments = cv2.moments(contour)

            if moments["m00"] == 0:
                continue

            cx = moments["m10"] / moments["m00"]
            cy = moments["m01"] / moments["m00"]

            column = int(round(cx / CELL_SIZE))
            row = int(round(cy / CELL_SIZE))

            column = max(1, min(11, column))
            row = max(1, min(11, row))

            column_name = chr(ord("A") + column - 1)

            locations.append(
                f"{column_name}{row}"
            )

        results[category] = locations

    return results


def main():

    parser = argparse.ArgumentParser(
        description="Khojo Drone Task 1A"
    )

    parser.add_argument(
        "--image",
        required=True,
        help="Path to input arena image"
    )

    args = parser.parse_args()

    image_path = os.path.abspath(args.image)

    image = cv2.imread(image_path)

    if image is None:
        raise RuntimeError(
            f"Could not load image: {image_path}"
        )

    marker_points = detect_markers(image)

    warped = perspective_transform(
        image,
        marker_points
    )

    results = detect_survivors(warped)

    detected_ids = sorted(marker_points.keys())

    output_path = (
        os.path.splitext(image_path)[0]
        + "_results.txt"
    )

    with open(output_path, "w") as file:

        file.write(
            f"Detected marker IDs: {detected_ids}\n\n"
        )

        file.write(
            "Critical Survivors: "
            + ", ".join(results["Critical Survivors"])
            + "\n"
        )

        file.write(
            "Stable Survivors: "
            + ", ".join(results["Stable Survivors"])
            + "\n"
        )

    print(f"Results saved to: {output_path}")


if __name__ == "__main__":
    main()
